import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  IonPage,
  IonContent,
  IonInput,
  IonButton,
  IonIcon,
  IonText,
  IonSpinner,
} from '@ionic/react';
import { mailOutline, lockClosedOutline, eyeOutline, eyeOffOutline } from 'ionicons/icons';
import { useAuth } from '../context/AuthContext';
import logo from '../assets/aarna-logo.jpeg';
import { apiPost } from '../api';
import './Login.css';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Enter your email and password to continue.');
      return;
    }

    setLoading(true);
    try {
      // Backend accepts mobile OR email in `identifier`.
      const res = await apiPost('/auth/login', {
        identifier: email,
        password,
      });

      login(res.user, res.token);
      navigate('/home', { replace: true });
    } catch (err: any) {
      setError(err?.error || 'That email and password combination didn’t work.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <IonPage className="login-page">
      <IonContent fullscreen scrollY={false} className="login-content">
        <div className="login-frame">
          <div className="login-scroll">
            <div className="brand-mark">
              <img src={logo} alt="Aarna Market OS" className="brand-logo" />
            </div>

            <header className="login-header">
              <h1>Welcome back</h1>
              <p>Sign in to manage your storefront on Aarna Market OS.</p>
            </header>

            <form className="login-form" onSubmit={handleLogin} noValidate>
              <label className="field-label" htmlFor="login-email">
                Email
              </label>
              <div className="input-shell">
                <IonIcon icon={mailOutline} aria-hidden="true" />
                <IonInput
                  id="login-email"
                  type="email"
                  inputmode="email"
                  placeholder="you@business.com"
                  value={email}
                  autocomplete="email"
                  onIonInput={(e) => setEmail(e.detail.value ?? '')}
                />
              </div>

              <div className="field-row">
                <label className="field-label" htmlFor="login-password">
                  Password
                </label>
                <button type="button" className="link-inline">
                  Forgot password?
                </button>
              </div>
              <div className="input-shell">
                <IonIcon icon={lockClosedOutline} aria-hidden="true" />
                <IonInput
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  autocomplete="current-password"
                  onIonInput={(e) => setPassword(e.detail.value ?? '')}
                />
                <button
                  type="button"
                  className="visibility-toggle"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  onClick={() => setShowPassword((v) => !v)}
                >
                  <IonIcon icon={showPassword ? eyeOffOutline : eyeOutline} />
                </button>
              </div>

              {error && (
                <IonText color="danger" className="form-error">
                  {error}
                </IonText>
              )}

              <IonButton
                expand="block"
                type="submit"
                className="cta-button"
                disabled={loading}
              >
                {loading ? <IonSpinner name="dots" /> : 'Sign in'}
              </IonButton>
            </form>

            <p className="signup-line">
              New to Aarna?{' '}
              <button
                type="button"
                className="link-inline strong"
                onClick={() => navigate('/register')}
              >
                Create an account
              </button>
            </p>
          </div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default Login;